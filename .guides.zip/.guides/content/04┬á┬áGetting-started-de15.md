﻿0.4  Getting started {#sec5 .section}
--------------------

[]{#code}

To run the examples and work on the exercises in this book, you have to:

1.  Install Python on your computer, along with the libraries we will
    use.
2.  Copy my files onto your computer.
3.  Run Jupyter, which is a tool for running and writing programs, and
    load a [notebook]{style="font-weight:bold"}, which is a file that
    contains code and text.

The next three sections provide details for these steps. I wish there
were an easier way to get started; it's regrettable that you have to do
so much work before you write your first program. Be persistent!

