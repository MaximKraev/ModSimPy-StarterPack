﻿Chapter 10  Case studies {#sec61 .chapter}
========================

[]{#chap10}

This chapter reviews the computational patterns we have seen so far and
presents exercises where you can apply them.

