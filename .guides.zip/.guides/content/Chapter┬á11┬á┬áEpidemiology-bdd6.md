﻿Chapter 11  Epidemiology {#sec67 .chapter}
========================

[]{#chap11}

In this chapter, we develop a model of an epidemic as it spreads in a
susceptible population, and use it to evaluate the effectiveness of
possible interventions.

[]{#hevea_default276}

My presentation of the SIR model in the next few chapters is based on an
excellent article by David Smith and Lang Moore^[1](#note6){#text6}^.

[]{#hevea_default277}

