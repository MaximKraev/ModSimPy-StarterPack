﻿Chapter 12  Optimization {#sec76 .chapter}
========================

[]{#chap12}

In the previous chapter I presented the SIR model of infectious disease
and used it to model the Freshman Plague at Olin. In this chapter we'll
consider metrics intended to quantify the effect of the disease and
interventions that might reduce the negative effects.

