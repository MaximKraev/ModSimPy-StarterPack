﻿Chapter 14  Analysis {#sec85 .chapter}
====================

[]{#chap14}

In the previous chapters we used simulation to predict the effect of an
infectious disease in a susceptible population and to design
interventions that would minimize the effect.

In this chapter we use analysis to investigate the relationship between
the parameters, `beta` and `gamma`, and the outcome of the simulation.

