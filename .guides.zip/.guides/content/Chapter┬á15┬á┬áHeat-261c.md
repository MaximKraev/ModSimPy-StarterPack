﻿Chapter 15  Heat {#sec89 .chapter}
================

[]{#chap15}

So far the systems we have studied have been physical in the sense that
they exist in the world, but they have not been physics, in the sense of
what physics classes are usually about. In the next few chapters, we'll
do some physics, starting with [thermal
systems]{style="font-weight:bold"}, that is, systems where the
temperature of objects changes as heat transfers from one to another.

[]{#hevea_default363}

