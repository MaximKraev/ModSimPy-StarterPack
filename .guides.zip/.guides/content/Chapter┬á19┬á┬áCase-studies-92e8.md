﻿Chapter 19  Case studies {#sec111 .chapter}
========================

[]{#chap19}

This chapter reviews the computational patterns we have seen so far and
presents exercises where you can apply them.

