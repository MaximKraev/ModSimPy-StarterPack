﻿Chapter 21  Air resistance {#sec121 .chapter}
==========================

[]{#chap21}

In the previous chapter we simulated a penny falling in a vacuum, that
is, without air resistance. But the computational framework we used is
very general; it is easy to add additional forces, including drag.

In this chapter, I present a model of drag force and add it to the
simulation.

