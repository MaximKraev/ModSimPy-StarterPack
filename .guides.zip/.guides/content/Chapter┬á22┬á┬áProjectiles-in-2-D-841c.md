﻿Chapter 22  Projectiles in 2-D {#sec126 .chapter}
==============================

[]{#chap22}

In the previous chapter we modeled objects moving in one dimension, with
and without drag. Now let's move on to two dimensions, and baseball!

In this chapter we model the flight of a baseball including the effect
of air resistance. In the next chapter we use this model to solve an
optimization problem.

