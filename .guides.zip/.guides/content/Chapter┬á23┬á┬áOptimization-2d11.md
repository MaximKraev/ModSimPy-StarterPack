﻿Chapter 23  Optimization {#sec131 .chapter}
========================

[]{#chap23}

In the previous chapter we developed a model of the flight of a
baseball, including gravity and a simple version of drag, but neglecting
spin, Magnus force, and the dependence of the coefficient of drag on
velocity.

In this chapter we apply that model to an optimization problem.

