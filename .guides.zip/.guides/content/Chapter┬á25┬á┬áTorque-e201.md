﻿Chapter 25  Torque {#sec139 .chapter}
==================

[]{#chap25}

In the previous chapter we modeled a scenario with constant angular
velocity. In this chapter we make it more complex; we'll model a teapot,
on a turntable, revolving with constant angular acceleration and
deceleration.

