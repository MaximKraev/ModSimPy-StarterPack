﻿Chapter 26  Case studies {#sec144 .chapter}
========================

[]{#chap26}

