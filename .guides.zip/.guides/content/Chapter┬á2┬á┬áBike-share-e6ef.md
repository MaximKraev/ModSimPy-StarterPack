﻿Chapter 2  Bike share {#sec13 .chapter}
=====================

[]{#chap02}

This chapter presents a simple model of a bike share system and
demonstrates the features of Python we'll use to develop simulations of
real-world systems.

Along the way, we'll make decisions about how to model the system. In
the next chapter we'll review these decisions and gradually improve the
model.

