﻿Chapter 6  Modeling growth {#sec40 .chapter}
==========================

[]{#chap06} In the previous chapter we simulated a model of world
population with constant growth. In this chapter we see if we can make a
better model with growth proportional to the population.

But first, we can improve the code from the previous chapter by
encapsulating it in a function and using `System` objects.

