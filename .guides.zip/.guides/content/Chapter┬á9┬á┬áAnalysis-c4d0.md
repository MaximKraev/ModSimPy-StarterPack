﻿Chapter 9  Analysis {#sec52 .chapter}
===================

[]{#chap09}

In this chapter we express the models from previous chapters as
difference equations and differential equations, solve the equations,
and derive the functional forms of the solutions. We also discuss the
complementary roles of mathematical analysis and simulation.

