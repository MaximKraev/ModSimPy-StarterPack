﻿Contributor List {#sec9 .section}
----------------

If you have a suggestion or correction, send it to
[downey\@allendowney.com]{style="font-family:monospace"}. Or if you are
a Git user, send me a pull request!

If I make a change based on your feedback, I will add you to the
contributor list, unless you ask to be omitted. []{#hevea_default19}

If you include at least part of the sentence the error appears in, that
makes it easy for me to search. Page and section numbers are fine, too,
but not as easy to work with. Thanks!

-   I am grateful to John Geddes and Mark Somerville for their early
    collaboration with me to create Modeling and Simulation, the class
    at Olin College this book is based on.
-   My early work on this book benefited from conversations with my
    amazing colleagues at Olin College, including John Geddes, Alison
    Wood, Chris Lee, and Jason Woodard.
-   I am grateful to Lisa Downey and Jason Woodard for their thoughtful
    and careful copy editing.
-   Thanks to Alessandra Ferzoco, Erhardt Graeff, Emily Tow, Kelsey
    Houston-Edwards, Linda Vanasupa, Matt Neal, Joanne Pratt, and Steve
    Matsumoto for their helpful suggestions.
