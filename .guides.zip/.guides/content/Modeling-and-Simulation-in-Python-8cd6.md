﻿[Modeling and Simulation in Python]{style="font-size:x-large"}

[Allen B. Downey]{style="font-size:large"}

Version 2.2.7

\

Copyright © 2017 Allen B. Downey.

Permission is granted to copy, distribute, and/or modify this work under
the terms of the Creative Commons Attribution-NonCommercial-ShareAlike
4.0 International License, which is available at
[[https://modsimpy.com/license]{style="font-family:monospace"}](https://modsimpy.com/license).

\

